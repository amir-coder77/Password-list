
import random
import string

def generate_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''
    for _ in range(length):
        password += random.choice(characters)
    return password

# تعیین طول کد‌های پسورد مورد نظر
password_length = 30

# تعداد کد‌های پسورد مورد نظر
password_count = 100

passwords = []
for _ in range(password_count):
    password = generate_password(password_length)
    passwords.append(password)

print(passwords)